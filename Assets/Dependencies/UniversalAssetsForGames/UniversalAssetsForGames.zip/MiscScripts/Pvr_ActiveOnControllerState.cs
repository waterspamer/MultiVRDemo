﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pvr_UnitySDKAPI;

public class Pvr_ActiveOnControllerState : MonoBehaviour
{
    public List<GameObject> Objects;
    public int HandId = 0;
    public ControllerState TargetState = ControllerState.Connected;

    private bool _state = true;

    private void LateUpdate()
    {
        bool newState = Controller.UPvr_GetControllerState(HandId) == TargetState;
        if (_state != newState)
        {
            _state = newState;
            foreach (GameObject go in Objects)
            {
                if (go != null)
                {
                    go.SetActive(_state);
                }
            }
        }
    }
}
